create procedure copy_order_data2()
BEGIN
  -- 需要定义接收游标数据的变量 
  DECLARE done BOOLEAN DEFAULT 0 ;
  -- 自定义变量
  -- DECLARE var_price DOUBLE DEFAULT NULL ;
  -- DECLARE var_pay_time TIMESTAMP DEFAULT NULL ;
  -- DECLARE var_product VARCHAR (100) DEFAULT NULL ;
  DECLARE HH_HNAME VARCHAR (255) DEFAULT NULL ;
  -- 声明游标
  DECLARE cur CURSOR FOR 
  -- 作用于哪个语句
  SELECT 
    H_HNAME
  FROM
	t0925_c9
	where H_HIDTYPE=0;
  -- 设置结束标志
  -- 这条语句定义了一个 CONTINUE HANDLER，它是在条件出现时被执行的代码。这里，它指出当 SQLSTATE '02000'出现时，SET done=1 。SQLSTATE '02000'是一个未找到条件，当REPEAT由于没有更多的行供循环而不能继续时，出现这个条件
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1 ;
  -- 打开游标
  OPEN cur ;
  -- 使用repeat循环语法
  REPEAT
    -- 批读取数据到指定变量上
    FETCH cur INTO 
    HH_HNAME ;
    -- 进行逻辑操作
   select * from enterprise_t where E_ENAME like HH_HNAME;
    -- 循环结束条件
    UNTIL done 
  END REPEAT ;
  -- 关闭游标
  CLOSE cur ;
END;

